// AMOD REALIX — configuration
// ENGINE_URL vide = mode démo (aucune vraie génération, aucun coût).
// Quand le moteur Supabase sera installé, on mettra ici l'adresse de la fonction,
// par ex. "https://xxxx.supabase.co/functions/v1/realix". Les clés Google / ElevenLabs
// restent sur le serveur : elles ne sont JAMAIS mises dans l'application.
window.REALIX_CONFIG = {
  ENGINE_URL: "",
  ENGINE_PUBLIC_KEY: "",
  WHATSAPP: "224622585777",
  EMAIL: "abdallahdoukoure9@gmail.com",
  DEMO_START_CREDITS: 60,
  // 1 crédit = 1 000 GNF
  PACKS: [
    { id: "p50", credits: 50, price: 50000, label: "Découverte" },
    { id: "p120", credits: 120, price: 100000, label: "Créateur", badge: "+20 offerts" },
    { id: "p300", credits: 300, price: 230000, label: "Pro", badge: "Meilleur prix" },
    { id: "p800", credits: 800, price: 560000, label: "Entreprise", badge: "Agences" }
  ],
  // crédits par seconde de vidéo
  QUALITY: {
    lite: { label: "Essentiel", perSec: 1, desc: "Rapide, idéal pour tester" },
    standard: { label: "Standard", perSec: 2, desc: "Très réaliste, voix naturelle" },
    premium: { label: "Premium", perSec: 6, desc: "Qualité cinéma maximale" }
  },
  DUB_PER_SEC: 2,      // traduction : crédits par seconde et par langue
  LIPSYNC_PER_SEC: 1,  // lèvres synchronisées : en plus
  ASSEMBLE_COST: 5
};
