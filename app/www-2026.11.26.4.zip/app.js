/* AMOD REALIX — application (mode démo + client du moteur IA) */
(function () {
  "use strict";
  const C = window.REALIX_CONFIG;
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmtGNF = (n) => n.toLocaleString("fr-FR").replace(/ | /g, " ") + " GNF";
  let DEMO = true; // devient false quand le moteur répond « prêt »

  /* ---------- stockage ---------- */
  const store = {
    get(k, d) { try { const v = localStorage.getItem("rx_" + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem("rx_" + k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  };
  // crédits gratuits (démo / offerts) et crédits payés (achetés)
  let credits = store.get("credits", null);
  if (credits == null) { credits = C.DEMO_START_CREDITS; store.set("credits", credits); }
  let paid = store.get("paid", 0);
  let videos = store.get("videos", []);
  let userId = store.get("uid", null);
  if (!userId) { userId = "RX-" + Math.random().toString(36).slice(2, 8).toUpperCase(); store.set("uid", userId); }
  const blobs = {}; // vidéos importées (session seulement)

  function saveVideos() {
    while (!store.set("videos", videos) && videos.length > 1) videos.pop();
  }
  const total = () => credits + paid;
  function setCredits(n) { credits = Math.max(0, n); store.set("credits", credits); $("#creditCount").textContent = total(); }
  function setPaid(n) { paid = Math.max(0, n); store.set("paid", paid); $("#creditCount").textContent = total(); }

  /* ---------- langues & voix ---------- */
  const LANGS = [
    ["fr", "Français", "fr-FR"], ["en", "Anglais", "en-US"], ["ar", "Arabe", "ar-SA"], ["es", "Espagnol", "es-ES"],
    ["pt", "Portugais", "pt-PT"], ["de", "Allemand", "de-DE"], ["it", "Italien", "it-IT"], ["tr", "Turc", "tr-TR"],
    ["ru", "Russe", "ru-RU"], ["zh", "Chinois", "zh-CN"], ["ja", "Japonais", "ja-JP"], ["ko", "Coréen", "ko-KR"],
    ["hi", "Hindi", "hi-IN"], ["ur", "Ourdou", "ur-PK"], ["id", "Indonésien", "id-ID"], ["ms", "Malais", "ms-MY"],
    ["nl", "Néerlandais", "nl-NL"], ["pl", "Polonais", "pl-PL"], ["sv", "Suédois", "sv-SE"], ["el", "Grec", "el-GR"],
    ["fa", "Persan", "fa-IR"], ["bn", "Bengali", "bn-IN"], ["ta", "Tamoul", "ta-IN"], ["sw", "Swahili", "sw-KE"],
    ["ha", "Haoussa (expérimental)", "ha"], ["yo", "Yoruba (expérimental)", "yo"], ["wo", "Wolof (expérimental)", "wo"],
    ["ff", "Peul / Pular (expérimental)", "ff"], ["sus", "Soussou (expérimental)", "sus"], ["man", "Malinké (expérimental)", "man"]
  ];
  const langName = (c) => (LANGS.find((l) => l[0] === c) || [c, c])[1];
  const langTTS = (c) => (LANGS.find((l) => l[0] === c) || [0, 0, "fr-FR"])[2];
  const langOptions = (sel) => LANGS.map((l) => `<option value="${l[0]}"${l[0] === sel ? " selected" : ""}>${l[1]}</option>`).join("");
  const VOICES = [["homme", "Homme"], ["femme", "Femme"], ["jeune_h", "Jeune homme"], ["jeune_f", "Jeune femme"], ["age_h", "Homme âgé"], ["age_f", "Femme âgée"], ["enfant", "Enfant"]];
  const TONES = ["Chaleureux", "Énergique", "Sérieux", "Joyeux", "Émouvant", "Calme", "Commercial", "Autoritaire"];
  const FORMATS = [["9:16", "Vertical (TikTok, WhatsApp)"], ["16:9", "Horizontal (YouTube)"], ["1:1", "Carré (Facebook)"]];
  const MODES = {
    text: { ic: '<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h10M4 18h7"/><path d="M15.5 17.5l4-4 1.5 1.5-4 4H15.5z"/></svg>', t: "Texte → Vidéo", d: "Décrivez la scène, l'acteur parle avec une voix naturelle" },
    photo: { ic: '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="12" cy="10" r="3.2"/><path d="M6.5 19c1.2-2.6 3.2-3.8 5.5-3.8s4.3 1.2 5.5 3.8"/></svg>', t: "Photo qui parle", d: "Une photo devient une vidéo où la personne parle" },
    dub: { ic: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.5 3.8 5.5 3.8 9s-1.2 6.5-3.8 9c-2.6-2.5-3.8-5.5-3.8-9S9.4 5.5 12 3z"/></svg>', t: "Traduire une vidéo", d: "Doublage dans n'importe quelle langue, lèvres synchronisées" },
    merge: { ic: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M7 5v14M17 5v14M3 9.5h4M3 14.5h4M17 9.5h4M17 14.5h4"/></svg>', t: "Assembler", d: "Réunir plusieurs clips en une longue vidéo" }
  };

  /* ---------- interface de base ---------- */
  function toast(m, ms = 2600) { const t = $("#toast"); t.textContent = m; t.classList.remove("hidden"); clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.add("hidden"), ms); }
  function sheet(html) { $("#sheetBody").innerHTML = html; $("#sheet").classList.remove("hidden"); }
  function closeSheet() { $("#sheet").classList.add("hidden"); }
  $("#sheet").addEventListener("click", (e) => { if (e.target.id === "sheet" || e.target.dataset.close != null) closeSheet(); });
  document.addEventListener("click", (e) => { const g = e.target.closest("[data-go]"); if (g) { e.preventDefault(); go(g.dataset.go); } });

  let current = "home";
  function go(v, p) {
    stopPlayback();
    current = v;
    $$(".tabs button").forEach((b) => b.classList.toggle("on", b.dataset.go === v || (v === "form" && b.dataset.go === "home")));
    const view = $("#view");
    view.innerHTML = "";
    (VIEWS[v] || VIEWS.home)(view, p || {});
    window.scrollTo(0, 0);
  }

  /* ---------- écrans ---------- */
  const VIEWS = {};

  VIEWS.home = (el) => {
    el.innerHTML = `
      <section class="hero">
        <span class="kicker">Studio vidéo IA</span>
        <h1>Créez des vidéos ultra réalistes</h1>
        <p>Des acteurs qui parlent avec une voix naturelle, dans plus de 30 langues.</p>
        <div class="stats"><div><b>30+</b><span>langues</span></div><div><b>100 %</b><span>voix naturelle</span></div><div><b>HD</b><span>jusqu'à 4K</span></div></div>
      </section>
      <div class="sec-title">Que voulez-vous créer ?</div>
      <div class="modes">${Object.entries(MODES).map(([k, m]) => `
        <button class="mode" data-mode="${k}"><div class="ibox">${m.ic}</div><b>${m.t}</b><span>${m.d}</span></button>`).join("")}
      </div>
      <div class="sec-title">Idées pour démarrer</div>
      <div class="list">
        <button data-idea="0"><div><b>Pub pour une boutique</b><br><span>Un vendeur souriant présente ses produits au marché</span></div>›</button>
        <button data-idea="1"><div><b>Annonce de voyage</b><br><span>Une hôtesse invite à réserver un billet pour La Mecque</span></div>›</button>
        <button data-idea="2"><div><b>Message de bienvenue</b><br><span>Un chef d'entreprise accueille ses clients en anglais</span></div>›</button>
      </div>
      ${videos.length ? `<div class="sec-title">Dernières vidéos <button class="link" data-go="library">Tout voir</button></div><div class="lib">${videos.slice(0, 2).map(itemHTML).join("")}</div>` : ""}`;
    $$(".mode", el).forEach((b) => b.onclick = () => go("form", { mode: b.dataset.mode }));
    $$("[data-idea]", el).forEach((b) => b.onclick = () => go("form", { mode: "text", idea: IDEAS[+b.dataset.idea] }));
    bindItems(el);
  };

  const IDEAS = [
    { scene: "Un commerçant guinéen d'environ 35 ans, en chemise blanche, debout devant sa boutique animée au marché Madina à Conakry, regarde la caméra en souriant", dialogue: "Venez chez nous, les meilleurs prix de Conakry, livrés chez vous aujourd'hui !", tone: "Commercial", voice: "homme", lang: "fr" },
    { scene: "Une hôtesse africaine élégante, voile beige, dans une agence de voyage moderne et lumineuse, parle face caméra", dialogue: "Partez pour la Omra en toute sérénité, nous nous occupons de tout.", tone: "Chaleureux", voice: "femme", lang: "fr" },
    { scene: "Un chef d'entreprise africain en costume bleu marine, dans un bureau vitré avec vue sur la ville, parle avec assurance", dialogue: "Welcome to our company, we are proud to serve you every day.", tone: "Sérieux", voice: "homme", lang: "en" }
  ];

  VIEWS.form = (el, p) => {
    const mode = p.mode || "text";
    const m = MODES[mode];
    el.innerHTML = `<button class="back" data-go="home">‹ Retour</button><div class="form-head"><div class="ibox">${m.ic}</div><div><h1>${m.t}</h1><p class="sub" style="margin:0">${m.d}</p></div></div><div id="formBody"></div>`;
    FORMS[mode]($("#formBody", el), p);
  };

  /* --- éléments communs des formulaires --- */
  const st = {};
  function chipGroup(name, list, sel) {
    return `<div class="chips" data-group="${name}">${list.map((x) => { const [v, l] = Array.isArray(x) ? x : [x, x]; return `<button type="button" class="chip${v === sel ? " on" : ""}" data-v="${esc(v)}">${esc(l)}</button>`; }).join("")}</div>`;
  }
  function bindChips(el, onChange) {
    $$("[data-group]", el).forEach((g) => {
      st[g.dataset.group] = ($(".chip.on", g) || {}).dataset?.v;
      g.onclick = (e) => { const b = e.target.closest(".chip"); if (!b) return; $$(".chip", g).forEach((c) => c.classList.remove("on")); b.classList.add("on"); st[g.dataset.group] = b.dataset.v; onChange && onChange(); };
    });
  }
  function qualityBlock(sel = "standard") {
    return `<label class="f">Qualité</label><div class="q" data-q>${Object.entries(C.QUALITY).map(([k, q]) => `<button type="button" data-v="${k}" class="${k === sel ? "on" : ""}"><b>${q.label}</b><small>${q.desc}</small></button>`).join("")}</div>`;
  }
  function bindQuality(el, onChange) {
    const q = $("[data-q]", el); st.quality = $(".on", q).dataset.v;
    q.onclick = (e) => { const b = e.target.closest("button"); if (!b) return; $$("button", q).forEach((x) => x.classList.remove("on")); b.classList.add("on"); st.quality = b.dataset.v; onChange(); };
  }
  function costLine(n) { return `<div class="cost"><span>Coût de cette vidéo</span><b>${n} crédits <small style="color:var(--mute);font-weight:400">≈ ${fmtGNF(n * 1000)}</small></b></div>`; }
  function wordsCheck(text, sec) {
    const w = (text || "").trim().split(/\s+/).filter(Boolean).length; const max = Math.round(sec * 2.6);
    return w > max ? `<p class="note" style="color:#fcd38a">⚠ ${w} mots pour ${sec} s : c'est trop rapide. Gardez environ ${max} mots maximum pour une voix naturelle.</p>` : `<p class="note">${w} / ${max} mots conseillés pour ${sec} secondes.</p>`;
  }
  function fileToDataURL(file, maxW = 1024, q = 0.85) {
    return new Promise((res, rej) => {
      const img = new Image(); const url = URL.createObjectURL(file);
      img.onload = () => { const s = Math.min(1, maxW / Math.max(img.width, img.height)); const c = document.createElement("canvas"); c.width = img.width * s; c.height = img.height * s; c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res(c.toDataURL("image/jpeg", q)); };
      img.onerror = rej; img.src = url;
    });
  }

  const FORMS = {};

  /* --- Texte → Vidéo --- */
  FORMS.text = (el, p) => {
    const i = p.idea || {};
    el.innerHTML = `
      <div class="card">
        <label class="f">1. Décrivez la scène <small>(qui, où, quoi)</small></label>
        <textarea id="scene" placeholder="Ex : une femme guinéenne de 30 ans, en tenue wax colorée, dans un salon de coiffure à Kaloum, parle à la caméra en souriant">${esc(i.scene)}</textarea>
        <label class="f">2. Ce que l'acteur dit <small>(paroles exactes)</small></label>
        <textarea id="dialogue" placeholder="Ex : Bienvenue chez Fatou Beauté, votre beauté est notre passion !">${esc(i.dialogue)}</textarea>
        <div id="wc"></div>
        <label class="f">3. Langue de la voix</label>
        <select id="lang">${langOptions(i.lang || "fr")}</select>
        <label class="f">Accent / précision <small>(facultatif)</small></label>
        <input type="text" id="accent" placeholder="Ex : léger accent guinéen, accent du Golfe…">
        <label class="f">4. Voix</label>${chipGroup("voice", VOICES, i.voice || "homme")}
        <label class="f">Ton</label>${chipGroup("tone", TONES, i.tone || "Chaleureux")}
      </div>
      <div class="card">
        <label class="f">Format</label>${chipGroup("format", FORMATS.map((f) => [f[0], f[0] + " · " + f[1].split(" ")[0]]), "9:16")}
        <label class="f">Durée</label>${chipGroup("dur", [["4", "4 s"], ["6", "6 s"], ["8", "8 s"]], "8")}
        ${qualityBlock()}
        <label class="f">Ambiance sonore <small>(facultatif)</small></label>
        <input type="text" id="ambiance" placeholder="Ex : bruits de marché, oiseaux, musique douce…">
        <label class="check"><input type="checkbox" id="nosub" checked> Sans sous-titres dans la vidéo</label>
        <div id="cost"></div>
        <button class="btn ghost" id="seePrompt" type="button">Voir la consigne envoyée à l'IA</button>
        <label class="check"><input type="checkbox" id="rules"> Je confirme que cette vidéo ne copie pas le visage ou la voix d'une vraie personne sans son accord.</label>
        <button class="btn" id="go">Générer la vidéo</button>
      </div>`;
    const upd = () => {
      const sec = +st.dur; $("#wc").innerHTML = wordsCheck($("#dialogue").value, sec);
      st.cost = sec * C.QUALITY[st.quality].perSec; $("#cost").innerHTML = costLine(st.cost);
    };
    bindChips(el, upd); bindQuality(el, upd); $("#dialogue").oninput = upd; upd();
    const data = () => ({
      mode: "text", scene: $("#scene").value.trim(), dialogue: $("#dialogue").value.trim(), lang: $("#lang").value,
      accent: $("#accent").value.trim(), voice: st.voice, tone: st.tone, format: st.format, duration: +st.dur,
      quality: st.quality, ambiance: $("#ambiance").value.trim(), noSubtitles: $("#nosub").checked, cost: st.cost
    });
    $("#seePrompt").onclick = () => sheet(`<h2 style="margin-top:0">Consigne envoyée à l'IA</h2><div class="card" style="white-space:pre-wrap;font-size:13.5px;line-height:1.5">${esc(buildPrompt(data()))}</div><button class="btn ghost" data-close>Fermer</button>`);
    $("#go").onclick = () => {
      const d = data();
      if (d.scene.length < 15) return toast("Décrivez la scène un peu plus (au moins une phrase).");
      if (!$("#rules").checked) return toast("Cochez la confirmation avant de générer.");
      d.prompt = buildPrompt(d); d.title = d.dialogue ? d.dialogue.slice(0, 60) : d.scene.slice(0, 60);
      startJob(d);
    };
  };

  function voiceText(v) {
    return { homme: "une voix d'homme adulte", femme: "une voix de femme adulte", jeune_h: "une voix de jeune homme", jeune_f: "une voix de jeune femme", age_h: "une voix d'homme âgé", age_f: "une voix de femme âgée", enfant: "une voix d'enfant" }[v] || "une voix naturelle";
  }
  function buildPrompt(d) {
    const ratio = { "9:16": "format vertical 9:16", "16:9": "format horizontal 16:9", "1:1": "format carré 1:1" }[d.format];
    let s = `Vidéo photoréaliste de qualité cinéma, ${ratio}, ${d.duration} secondes.\nScène : ${d.scene || "—"}.\n`;
    if (d.dialogue) s += `Le personnage regarde la caméra et dit en ${langName(d.lang).replace(" (expérimental)", "").toLowerCase()}, avec ${voiceText(d.voice)}, ton ${String(d.tone).toLowerCase()}${d.accent ? ", " + d.accent : ""} : « ${d.dialogue} »\nLes mouvements des lèvres sont parfaitement synchronisés avec la voix. La voix est naturelle, humaine, sans effet robotique.\n`;
    s += `Lumière naturelle, mouvements de caméra doux, visages et mains réalistes, peau naturelle.\n`;
    s += `Sons : ${d.ambiance || "ambiance discrète et réaliste correspondant au lieu"}.\n`;
    if (d.noSubtitles) s += "Sans sous-titres, sans texte à l'écran, sans musique ajoutée.";
    return s;
  }

  /* --- Photo qui parle --- */
  FORMS.photo = (el) => {
    let photo = null;
    el.innerHTML = `
      <div class="card">
        <label class="f">1. Choisissez une photo <small>(visage bien visible, de face)</small></label>
        <div class="drop" id="drop"><div class="ibox"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="12" cy="10" r="3.2"/><path d="M6.5 19c1.2-2.6 3.2-3.8 5.5-3.8s4.3 1.2 5.5 3.8"/></svg></div><b>Touchez pour choisir une photo</b><span>Galerie ou appareil photo</span><input type="file" id="file" accept="image/*"></div>
        <label class="f">2. Ce que la personne dit</label>
        <textarea id="dialogue" placeholder="Ex : Salam aleykoum, je vous présente notre nouvelle collection !"></textarea>
        <div id="wc"></div>
        <label class="f">3. Langue</label><select id="lang">${langOptions("fr")}</select>
        <label class="f">4. Voix</label>${chipGroup("voice", VOICES, "femme")}
        <label class="f">Émotion</label>${chipGroup("tone", TONES, "Joyeux")}
        <label class="f">Mouvement</label>${chipGroup("move", [["leger", "Léger (tête, yeux)"], ["naturel", "Naturel (gestes)"], ["dynamique", "Dynamique"]], "naturel")}
      </div>
      <div class="card">
        <label class="f">Durée</label>${chipGroup("dur", [["4", "4 s"], ["6", "6 s"], ["8", "8 s"]], "8")}
        ${qualityBlock()}
        <div id="cost"></div>
        <label class="check"><input type="checkbox" id="consent"> J'ai l'accord de la personne sur la photo (ou c'est moi). Je n'utilise pas la photo d'une personnalité ou d'un inconnu.</label>
        <button class="btn" id="go">Faire parler la photo</button>
      </div>`;
    const upd = () => { const sec = +st.dur; $("#wc").innerHTML = wordsCheck($("#dialogue").value, sec); st.cost = sec * C.QUALITY[st.quality].perSec; $("#cost").innerHTML = costLine(st.cost); };
    bindChips(el, upd); bindQuality(el, upd); $("#dialogue").oninput = upd; upd();
    $("#file").onchange = async (e) => {
      const f = e.target.files[0]; if (!f) return;
      try { photo = await fileToDataURL(f, 900, 0.82); $("#drop").innerHTML = `<img src="${photo}"><span>Touchez pour changer</span><input type="file" id="file" accept="image/*">`; $("#file").onchange = e.target.onchange; } catch (x) { toast("Impossible de lire cette photo."); }
    };
    $("#go").onclick = () => {
      if (!photo) return toast("Choisissez d'abord une photo.");
      const dialogue = $("#dialogue").value.trim(); if (!dialogue) return toast("Écrivez ce que la personne doit dire.");
      if (!$("#consent").checked) return toast("Confirmez que vous avez l'accord de la personne.");
      const d = { mode: "photo", photo, dialogue, lang: $("#lang").value, voice: st.voice, tone: st.tone, move: st.move, duration: +st.dur, quality: st.quality, cost: st.cost, format: "9:16", title: dialogue.slice(0, 60) };
      d.prompt = `Anime cette photo de façon photoréaliste (${d.move}). La personne parle en ${langName(d.lang).toLowerCase()}, ${voiceText(d.voice)}, émotion ${String(d.tone).toLowerCase()} : « ${dialogue} ». Lèvres synchronisées, clignements naturels, aucun texte à l'écran.`;
      startJob(d);
    };
  };

  /* --- Traduire une vidéo --- */
  FORMS.dub = (el) => {
    let vid = null, dur = 0;
    el.innerHTML = `
      <div class="card">
        <label class="f">1. Choisissez la vidéo à traduire</label>
        <div class="drop" id="drop"><div class="ibox"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.5 3.8 5.5 3.8 9s-1.2 6.5-3.8 9c-2.6-2.5-3.8-5.5-3.8-9S9.4 5.5 12 3z"/></svg></div><b>Touchez pour choisir une vidéo</b><span>Jusqu'à 2 minutes</span><input type="file" id="file" accept="video/*"></div>
        <label class="f">2. Langue parlée dans la vidéo</label>
        <select id="from"><option value="auto">Détection automatique</option>${langOptions("")}</select>
        <label class="f">3. Traduire en <small>(une ou plusieurs langues)</small></label>
        <div class="chips" id="targets">${LANGS.map((l) => `<button type="button" class="chip" data-v="${l[0]}">${l[1].replace(" (expérimental)", "*")}</button>`).join("")}</div>
        <p class="note">* Langues locales expérimentales : la qualité peut être plus faible.</p>
        <label class="check"><input type="checkbox" id="lips" checked> Synchroniser les lèvres avec la nouvelle langue</label>
        <label class="check"><input type="checkbox" id="keep" checked> Garder la même voix (même timbre, même émotion)</label>
      </div>
      <div class="card"><div id="cost"></div>
        <label class="check"><input type="checkbox" id="consent"> Je possède les droits de cette vidéo et l'accord des personnes qui y parlent.</label>
        <button class="btn" id="go">Traduire la vidéo</button></div>`;
    const sel = new Set();
    const upd = () => {
      const sec = Math.max(1, Math.ceil(dur || 0)); const per = C.DUB_PER_SEC + ($("#lips").checked ? C.LIPSYNC_PER_SEC : 0);
      st.cost = vid ? sec * per * Math.max(1, sel.size) : 0;
      $("#cost").innerHTML = vid ? costLine(st.cost) + `<p class="note">${sec} s × ${per} crédits × ${Math.max(1, sel.size)} langue(s)</p>` : `<p class="note">Le coût s'affiche après le choix de la vidéo.</p>`;
    };
    $("#targets").onclick = (e) => { const b = e.target.closest(".chip"); if (!b) return; b.classList.toggle("on"); sel[b.classList.contains("on") ? "add" : "delete"](b.dataset.v); upd(); };
    $("#lips").onchange = upd; upd();
    const onFile = (e) => {
      const f = e.target.files[0]; if (!f) return;
      vid = f; const url = URL.createObjectURL(f);
      $("#drop").innerHTML = `<video src="${url}" controls playsinline></video><span>Touchez à côté pour changer</span>`;
      const v = $("#drop video"); v.onloadedmetadata = () => { dur = v.duration; if (dur > 125) { toast("Vidéo trop longue : 2 minutes maximum."); vid = null; } upd(); };
    };
    $("#file").onchange = onFile;
    $("#go").onclick = async () => {
      if (!vid) return toast("Choisissez d'abord une vidéo.");
      if (!sel.size) return toast("Choisissez au moins une langue.");
      if (!$("#consent").checked) return toast("Confirmez que vous avez les droits de la vidéo.");
      const id = "b" + Date.now(); blobs[id] = vid;
      const thumb = await videoThumb(vid).catch(() => null);
      startJob({ mode: "dub", blobId: id, thumb, from: $("#from").value, targets: [...sel], lips: $("#lips").checked, keepVoice: $("#keep").checked, duration: Math.ceil(dur), cost: st.cost, format: "9:16", title: "Traduction → " + [...sel].map(langName).join(", ") });
    };
  };
  function videoThumb(file) {
    return new Promise((res, rej) => {
      const v = document.createElement("video"); v.muted = true; v.playsInline = true; v.preload = "auto"; v.src = URL.createObjectURL(file);
      v.onloadeddata = () => { v.currentTime = Math.min(1, v.duration / 3); };
      v.onseeked = () => { const c = document.createElement("canvas"); const s = 320 / Math.max(v.videoWidth, v.videoHeight); c.width = v.videoWidth * s; c.height = v.videoHeight * s; c.getContext("2d").drawImage(v, 0, 0, c.width, c.height); res(c.toDataURL("image/jpeg", 0.7)); };
      v.onerror = rej; setTimeout(() => rej("timeout"), 8000);
    });
  }

  /* --- Assembler --- */
  FORMS.merge = (el) => {
    const ready = videos.filter((v) => v.mode !== "merge");
    if (ready.length < 2) { el.innerHTML = `<div class="card empty">Il faut au moins <b>2 vidéos</b> dans « Mes vidéos » pour les assembler.<button class="btn" data-go="home">Créer une vidéo</button></div>`; return; }
    const order = [];
    el.innerHTML = `
      <div class="card"><label class="f">1. Touchez les clips dans l'ordre voulu</label>
        <div class="pick" id="pick">${ready.map((v) => `<button data-id="${v.id}" style="background-image:url('${v.thumb || ""}')"></button>`).join("")}</div>
        <div class="order" id="order"></div></div>
      <div class="card">
        <label class="f">Transition entre les clips</label>${chipGroup("trans", [["coupe", "Coupe nette"], ["fondu", "Fondu"], ["noir", "Fondu au noir"]], "fondu")}
        <label class="f">Titre au début <small>(facultatif)</small></label><input type="text" id="titre" placeholder="Ex : AMOD MARKET – Livraison partout à Conakry">
        <label class="f">Texte de fin <small>(facultatif)</small></label><input type="text" id="fin" placeholder="Ex : Appelez le 622 00 00 00">
        <label class="check"><input type="checkbox" id="music"> Ajouter une musique de fond douce</label>
        ${costLine(C.ASSEMBLE_COST)}
        <button class="btn" id="go">Assembler la vidéo</button></div>`;
    bindChips(el);
    const draw = () => {
      $$("#pick button").forEach((b) => { const k = order.indexOf(b.dataset.id); b.classList.toggle("on", k >= 0); b.innerHTML = k >= 0 ? `<em>${k + 1}</em>` : ""; });
      $("#order").innerHTML = order.map((id, k) => { const v = videos.find((x) => x.id === id); return `<div class="o"><img src="${v.thumb || ""}"><div><b>${k + 1}.</b> ${esc(v.title)}<br><span style="color:var(--mute)">${v.duration} s</span></div><button class="mini" data-up="${k}">↑</button><button class="mini" data-rm="${k}">✕</button></div>`; }).join("");
    };
    $("#pick").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; const k = order.indexOf(b.dataset.id); k >= 0 ? order.splice(k, 1) : order.push(b.dataset.id); draw(); };
    $("#order").onclick = (e) => { const u = e.target.dataset.up, r = e.target.dataset.rm; if (u > 0) { [order[u - 1], order[u]] = [order[u], order[u - 1]]; } if (r != null) order.splice(r, 1); draw(); };
    $("#go").onclick = () => {
      if (order.length < 2) return toast("Choisissez au moins 2 clips.");
      const parts = order.map((id) => videos.find((v) => v.id === id));
      startJob({ mode: "merge", clips: order, trans: st.trans, titre: $("#titre").value.trim(), fin: $("#fin").value.trim(), music: $("#music").checked, duration: parts.reduce((a, v) => a + (v.duration || 0), 0), cost: C.ASSEMBLE_COST, format: parts[0].format || "9:16", thumb: parts[0].thumb, title: $("#titre").value.trim() || `Montage de ${parts.length} clips` });
    };
  };

  /* ---------- génération ---------- */
  const STEPS = {
    text: ["Analyse de la scène", "Création de l'acteur et du décor", "Génération de la voix naturelle", "Synchronisation des lèvres", "Finalisation de la vidéo"],
    photo: ["Analyse du visage", "Animation de la photo", "Génération de la voix", "Synchronisation des lèvres", "Finalisation"],
    dub: ["Transcription de la vidéo", "Traduction", "Clonage de la voix", "Doublage et lèvres synchronisées", "Finalisation"],
    merge: ["Préparation des clips", "Transitions", "Titres et son", "Exportation"]
  };

  async function startJob(d) {
    // vidéo payée (sans mention IA) si les crédits achetés suffisent, sinon crédits gratuits (avec mention)
    d.paidVideo = paid >= d.cost;
    d.watermark = !d.paidVideo;
    if (!d.paidVideo && credits < d.cost) {
      sheet(`<h2 style="margin-top:0">Crédits insuffisants</h2><p class="sub">Cette vidéo coûte <b>${d.cost} crédits</b>, il vous en reste <b>${total()}</b>.</p><button class="btn" data-close data-go="credits">Acheter des crédits</button><button class="btn ghost" data-close>Annuler</button>`);
      return;
    }
    const el = $("#view");
    el.innerHTML = `<h1>Création en cours…</h1><p class="sub">${esc(d.title)}</p>
      <div class="card"><div class="progress"><i id="bar"></i></div><ul class="steps" id="steps">${STEPS[d.mode].map((s) => `<li>${s}</li>`).join("")}</ul>
      <p class="note" id="pnote">${DEMO ? "Mode démo : simulation de la génération." : "La génération prend en général 1 à 3 minutes. Vous pouvez laisser l'application ouverte."}</p></div>`;
    const steps = $$("#steps li"); const bar = $("#bar");
    const mark = (k) => { steps.forEach((li, i) => li.classList.toggle("done", i < k)); bar.style.width = Math.round((k / steps.length) * 100) + "%"; };
    let result;
    try {
      if (DEMO) {
        for (let k = 0; k <= steps.length; k++) { mark(k); if (current !== "job") { /* continue */ } await sleep(k === steps.length ? 300 : 900 + Math.random() * 700); }
        result = {};
      } else {
        result = await engineRun(d, (k) => mark(Math.min(steps.length - 1, k)));
        mark(steps.length);
      }
    } catch (e) {
      el.innerHTML = `<div class="card"><h2 style="margin-top:0">La génération a échoué</h2><p class="sub">${esc(e.message || e)}</p><p class="note">Vos crédits n'ont pas été retirés.</p><button class="btn" data-go="home">Réessayer</button></div>`;
      return;
    }
    if (d.paidVideo) setPaid(paid - d.cost); else setCredits(credits - d.cost);
    const v = Object.assign({}, d, { id: "v" + Date.now(), createdAt: Date.now(), demo: DEMO, url: result.video_url || null });
    if (v.mode === "photo") v.thumb = await shrink(d.photo, 360).catch(() => d.photo);
    if (v.mode === "text") v.thumb = textThumb(v);
    if (v.mode === "photo") v.photo = await shrink(d.photo, 640).catch(() => d.photo);
    videos.unshift(v); saveVideos();
    go("player", { id: v.id, fresh: true });
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function shrink(dataURL, w) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => { const s = Math.min(1, w / Math.max(i.width, i.height)); const c = document.createElement("canvas"); c.width = i.width * s; c.height = i.height * s; c.getContext("2d").drawImage(i, 0, 0, c.width, c.height); res(c.toDataURL("image/jpeg", 0.75)); }; i.onerror = rej; i.src = dataURL; }); }

  /* --- moteur réel (serveur Supabase) --- */
  async function engineRun(d, progress) {
    const payload = Object.assign({}, d, { user: userId });
    delete payload.blobId;
    if (d.mode === "dub") payload.video = await blobToDataURL(blobs[d.blobId]);
    if (d.mode === "merge") payload.clipUrls = d.clips.map((id) => (videos.find((v) => v.id === id) || {}).url).filter(Boolean);
    const h = { "Content-Type": "application/json" }; if (C.ENGINE_PUBLIC_KEY) { h.apikey = C.ENGINE_PUBLIC_KEY; h.Authorization = "Bearer " + C.ENGINE_PUBLIC_KEY; }
    const r = await fetch(C.ENGINE_URL + "/jobs", { method: "POST", headers: h, body: JSON.stringify(payload) });
    if (!r.ok) { const er = await r.json().catch(() => ({})); throw new Error(er.error || ("Le serveur a refusé la demande (" + r.status + ").")); }
    const { job_id } = await r.json();
    for (let i = 0; i < 120; i++) {
      await sleep(5000);
      const s = await fetch(C.ENGINE_URL + "/jobs/" + job_id, { headers: h }).then((x) => x.json());
      if (s.step != null) progress(s.step);
      if (s.status === "done") return s;
      if (s.status === "error") throw new Error(s.message || "Erreur du moteur IA.");
    }
    throw new Error("Délai dépassé. Réessayez plus tard.");
  }
  function blobToDataURL(b) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(b); }); }

  /* ---------- aperçu / lecteur ---------- */
  function dims(fmt, w = 540) { return fmt === "16:9" ? [w, Math.round(w * 9 / 16)] : fmt === "1:1" ? [w, w] : [Math.round(w * 9 / 16) * 1, w]; }
  function hue(s) { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return 10 + (h % 30); }
  function textThumb(v) {
    const c = document.createElement("canvas"); [c.width, c.height] = dims(v.format, 360); drawTextFrame(c.getContext("2d"), c.width, c.height, v, 0.4); return c.toDataURL("image/jpeg", 0.75);
  }
  function drawTextFrame(g, W, H, v, t) {
    const h = hue(v.scene || v.title);
    const gr = g.createLinearGradient(0, 0, W, H); gr.addColorStop(0, `hsl(${h},55%,${18 + 6 * Math.sin(t)}%)`); gr.addColorStop(1, `hsl(${(h + 200) % 360},35%,9%)`);
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
    for (let i = 0; i < 18; i++) { const x = (Math.sin(i * 7.1 + t * 0.6) * 0.5 + 0.5) * W, y = (Math.cos(i * 3.3 + t * 0.4) * 0.5 + 0.5) * H; g.fillStyle = `hsla(${(h + i * 3) % 360},95%,60%,.07)`; g.beginPath(); g.arc(x, y, 30 + i * 4, 0, 7); g.fill(); }
    // silhouette
    const cx = W / 2, cy = H * 0.52, s = Math.min(W, H) * 0.22, talk = Math.abs(Math.sin(t * 9)) * (v._talking ? 1 : 0);
    g.fillStyle = "rgba(0,0,0,.55)"; g.beginPath(); g.ellipse(cx, cy + s * 1.9, s * 1.5, s * 1.1, 0, Math.PI, 0); g.fill();
    g.beginPath(); g.arc(cx, cy, s * 0.75, 0, 7); g.fill();
    g.fillStyle = "rgba(255,255,255,.75)"; g.beginPath(); g.ellipse(cx, cy + s * 0.32, s * 0.2, s * 0.05 + talk * s * 0.12, 0, 0, 7); g.fill();
    g.fillStyle = "rgba(255,255,255,.9)"; g.font = `700 ${Math.round(W * 0.045)}px system-ui`; g.textAlign = "center";
    g.fillText("APERÇU DÉMO", cx, H * 0.1);
    g.font = `${Math.round(W * 0.034)}px system-ui`; g.fillStyle = "rgba(255,255,255,.7)";
    wrap(g, v.scene || "", cx, H * 0.16, W * 0.86, W * 0.045, 3);
  }
  function wrap(g, text, x, y, maxW, lh, maxL) {
    const words = text.split(" "); let line = "", n = 0;
    for (const w of words) { const test = line + w + " "; if (g.measureText(test).width > maxW && line) { g.fillText(line.trim(), x, y + n * lh); line = w + " "; if (++n >= maxL) { return; } } else line = test; }
    g.fillText(line.trim(), x, y + n * lh);
  }
  let raf = 0, playing = null;
  function stopPlayback() { cancelAnimationFrame(raf); raf = 0; try { speechSynthesis.cancel(); } catch (e) {} if (playing) { playing.pause && playing.pause(); playing = null; } }

  function speak(text, lang, voice, onend) {
    try {
      if (!("speechSynthesis" in window) || !text) { onend && setTimeout(onend, 3000); return; }
      const u = new SpeechSynthesisUtterance(text); const code = langTTS(lang); u.lang = code;
      const vs = speechSynthesis.getVoices().filter((x) => x.lang && x.lang.toLowerCase().startsWith(code.slice(0, 2).toLowerCase()));
      if (vs.length) u.voice = vs[0];
      u.pitch = /femme|_f|enfant/.test(voice) ? (voice === "enfant" ? 1.6 : 1.25) : voice?.startsWith("age") ? 0.8 : 0.9;
      u.rate = 0.95; u.onend = () => onend && onend(); u.onerror = () => onend && onend();
      speechSynthesis.speak(u);
    } catch (e) { onend && setTimeout(onend, 3000); }
  }

  VIEWS.player = (el, p) => {
    const v = videos.find((x) => x.id === p.id); if (!v) return go("library");
    const [W, H] = dims(v.format);
    el.innerHTML = `<button class="back" data-go="library">‹ Mes vidéos</button>
      ${p.fresh ? `<h1>Votre vidéo est prête ✨</h1>` : `<h1 style="font-size:19px">${esc(v.title)}</h1>`}
      <div class="player" id="pl">${v.url ? `<video src="${esc(v.url)}" controls playsinline></video>` : `<canvas id="cv" width="${W}" height="${H}"></canvas>`}${v.watermark !== false ? `<div class="wm">AMOD REALIX · IA</div>` : ""}</div>
      ${v.url ? "" : `<button class="btn" id="play">▶ Lire l'aperçu</button>`}
      ${v.demo ? `<p class="note">Aperçu démo : la voix est celle du téléphone et l'image est une animation de test. Avec le moteur IA activé, vous obtiendrez une vraie vidéo réaliste avec voix naturelle.</p>` : ""}
      <div class="row" style="margin-top:12px"><button class="btn ghost" id="dl" style="margin-top:0">⬇ Télécharger</button><button class="btn ghost" id="sh" style="margin-top:0">↗ Partager</button></div>
      <div class="card" style="margin-top:14px"><b>Détails</b><div class="note">${detailHTML(v)}</div></div>
      <div class="row"><button class="btn ghost" id="again">Refaire avec les mêmes réglages</button></div>
      <button class="btn ghost" id="del" style="color:#ff8a8a">Supprimer</button>`;
    const cv = $("#cv");
    if (cv) {
      const g = cv.getContext("2d"); let img = null;
      if (v.mode === "photo" && v.photo) { img = new Image(); img.src = v.photo; }
      const frame = (t) => {
        if (v.mode === "photo" && img && img.complete) {
          const z = 1.05 + 0.05 * Math.sin(t * 0.4), s = Math.max(W / img.width, H / img.height) * z;
          g.fillStyle = "#000"; g.fillRect(0, 0, W, H); g.drawImage(img, (W - img.width * s) / 2 + Math.sin(t * 0.3) * 8, (H - img.height * s) / 2, img.width * s, img.height * s);
          if (v._talking) { g.fillStyle = "rgba(236,72,153,.18)"; g.fillRect(0, H - 6, W * ((t * 0.12) % 1), 6); }
        } else if (v.mode === "merge" || v.mode === "dub") {
          const th = new Image(); th.src = v.thumb || ""; g.fillStyle = "#000"; g.fillRect(0, 0, W, H);
          if (th.complete && th.width) { const s = Math.max(W / th.width, H / th.height); g.drawImage(th, (W - th.width * s) / 2, (H - th.height * s) / 2, th.width * s, th.height * s); }
          g.fillStyle = "rgba(0,0,0,.45)"; g.fillRect(0, 0, W, H); g.fillStyle = "#fff"; g.textAlign = "center"; g.font = `700 ${Math.round(W * 0.05)}px system-ui`;
          g.fillText(v.mode === "dub" ? "DOUBLAGE DÉMO" : "MONTAGE DÉMO", W / 2, H * 0.45); g.font = `${Math.round(W * 0.036)}px system-ui`; wrap(g, v.title, W / 2, H * 0.53, W * 0.85, W * 0.05, 3);
        } else drawTextFrame(g, W, H, v, t);
      };
      frame(0.4);
      $("#play").onclick = () => {
        stopPlayback(); const t0 = performance.now(); v._talking = true;
        const loop = (n) => { frame((n - t0) / 1000); raf = requestAnimationFrame(loop); }; raf = requestAnimationFrame(loop);
        const end = () => { v._talking = false; setTimeout(() => { cancelAnimationFrame(raf); frame(0.4); }, 400); };
        if (v.mode === "dub" && blobs[v.blobId]) {
          cancelAnimationFrame(raf); const url = URL.createObjectURL(blobs[v.blobId]);
          $("#pl").innerHTML = `<video src="${url}" controls autoplay playsinline muted></video><div class="wm">DOUBLAGE DÉMO · ${esc(v.targets.map(langName).join(", "))}</div>`; playing = $("#pl video");
          toast("Démo : le vrai doublage remplacera la voix d'origine."); return;
        }
        if (v.mode === "merge") { toast("Démo : lecture du montage simulée."); setTimeout(end, Math.min(12000, v.duration * 1000)); return; }
        speak(v.dialogue, v.lang, v.voice, end);
      };
    }
    $("#dl").onclick = () => {
      if (!v.url) return toast("Le téléchargement sera disponible avec le moteur IA (mode démo).");
      const AL = window.Capacitor?.Plugins?.AppLauncher;
      if (AL) AL.openUrl({ url: v.url + "?download=AMOD-REALIX-" + v.id + ".mp4" }).catch(() => window.open(v.url, "_blank")); else window.open(v.url, "_blank");
    };
    $("#sh").onclick = async () => {
      const text = `Vidéo créée avec AMOD REALIX : ${v.title}`;
      if (v.url && navigator.share) { try { await navigator.share({ title: "AMOD REALIX", text, url: v.url }); } catch (e) {} }
      else if (v.url) window.open("https://wa.me/?text=" + encodeURIComponent(text + " " + v.url), "_blank");
      else toast("Le partage sera disponible avec le moteur IA (mode démo).");
    };
    $("#again").onclick = () => go("form", { mode: v.mode === "text" ? "text" : v.mode, idea: v.mode === "text" ? v : null });
    $("#del").onclick = () => { if (!confirmSheet) return; sheet(`<h2 style="margin-top:0">Supprimer cette vidéo ?</h2><button class="btn" id="yes" style="background:var(--bad)">Supprimer</button><button class="btn ghost" data-close>Annuler</button>`); $("#yes").onclick = () => { videos = videos.filter((x) => x.id !== v.id); saveVideos(); closeSheet(); go("library"); }; };
  };
  const confirmSheet = true;
  function detailHTML(v) {
    const q = C.QUALITY[v.quality]; const rows = [["Type", MODES[v.mode].t], ["Date", new Date(v.createdAt).toLocaleString("fr-FR")], ["Durée", (v.duration || "?") + " s"], ["Format", v.format]];
    if (q) rows.push(["Qualité", q.label]);
    if (v.lang) rows.push(["Langue", langName(v.lang)]);
    if (v.targets) rows.push(["Langues", v.targets.map(langName).join(", ")]);
    if (v.dialogue) rows.push(["Paroles", "« " + v.dialogue + " »"]);
    rows.push(["Crédits utilisés", v.cost]);
    return rows.map((r) => `<div style="padding:3px 0"><span style="color:var(--mute)">${r[0]} :</span> ${esc(r[1])}</div>`).join("");
  }

  /* ---------- bibliothèque ---------- */
  function itemHTML(v) {
    return `<div class="item" data-open="${v.id}"><div class="th" style="background-image:url('${v.thumb || ""}')"><span class="tag">${MODES[v.mode].t} · ${v.duration || "?"} s${v.demo ? " · démo" : ""}</span><div class="play">▶</div></div><div class="meta"><b>${esc(v.title)}</b><span>${new Date(v.createdAt).toLocaleDateString("fr-FR")}</span></div></div>`;
  }
  function bindItems(el) { $$("[data-open]", el).forEach((b) => b.onclick = () => go("player", { id: b.dataset.open })); }
  VIEWS.library = (el) => {
    el.innerHTML = `<h1>Mes vidéos</h1><p class="sub">${videos.length} vidéo(s)</p>` + (videos.length ? `<div class="lib">${videos.map(itemHTML).join("")}</div>` : `<div class="empty">Aucune vidéo pour l'instant.<button class="btn" data-go="home">Créer ma première vidéo</button></div>`);
    bindItems(el);
  };

  /* ---------- crédits ---------- */
  VIEWS.credits = (el) => {
    el.innerHTML = `<div class="big-balance"><span>Votre solde</span><b>${total()}</b><span>${paid} crédits achetés · ${credits} crédits offerts</span></div>
      <p class="note">Les vidéos faites avec des <b>crédits achetés</b> sont livrées <b>sans mention</b> à l'écran. Les crédits offerts (essai) ajoutent la mention « AMOD REALIX · IA ».</p>
      <h2>Acheter des crédits</h2><div class="packs">${C.PACKS.map((p) => `<div class="pack"><div><b>${p.credits} crédits</b>${p.badge ? `<span class="badge">${p.badge}</span>` : ""}<small>${p.label} · ${fmtGNF(p.price)}</small></div><button data-pack="${p.id}">Acheter</button></div>`).join("")}</div>
      <h2>Combien coûte une vidéo ?</h2>
      <div class="list">${Object.values(C.QUALITY).map((q) => `<div class="li"><div><b>${q.label}</b><br><span>${q.desc}</span></div><b>${q.perSec * 8} crédits / 8 s</b></div>`).join("")}
        <div class="li"><div><b>Traduction</b><br><span>par seconde et par langue, lèvres incluses</span></div><b>${C.DUB_PER_SEC + C.LIPSYNC_PER_SEC} crédits / s</b></div>
        <div class="li"><div><b>Assemblage</b><br><span>montage de plusieurs clips</span></div><b>${C.ASSEMBLE_COST} crédits</b></div></div>
      <p class="note">Votre identifiant client : <b>${userId}</b></p>`;
    $$("[data-pack]", el).forEach((b) => b.onclick = () => buy(C.PACKS.find((p) => p.id === b.dataset.pack)));
  };
  function buy(p) {
    sheet(`<h2 style="margin-top:0">${p.credits} crédits · ${fmtGNF(p.price)}</h2>
      <p class="sub">Choisissez votre moyen de paiement :</p>
      <div class="list">
        <button data-pay="om"><div><b><i class="dot om"></i>Orange Money</b><br><span>Paiement mobile en GNF</span></div>›</button>
        <button data-pay="carte"><div><b><i class="dot carte"></i>Carte bancaire</b><br><span>Visa, Mastercard</span></div>›</button>
      </div>
      <p class="note">Pour le moment, l'achat se confirme sur WhatsApp avec l'équipe AMOD REALIX : vous payez, et vos crédits sont ajoutés à votre identifiant <b>${userId}</b>. Le paiement automatique arrive bientôt.</p>
      <button class="btn ghost" data-close>Annuler</button>`);
    $$("[data-pay]").forEach((b) => b.onclick = () => {
      const moyen = b.dataset.pay === "om" ? "Orange Money" : "carte bancaire (Visa / Mastercard)";
      const msg = `Bonjour AMOD REALIX, je veux acheter le pack ${p.credits} crédits (${fmtGNF(p.price)}) par ${moyen}. Mon identifiant : ${userId}`;
      window.open(`https://wa.me/${C.WHATSAPP}?text=${encodeURIComponent(msg)}`, "_blank"); closeSheet();
    });
  }

  /* ---------- réglages ---------- */
  VIEWS.settings = (el) => {
    el.innerHTML = `<h1>Réglages</h1>
      <div class="list">
        <div class="li"><div><b>Moteur IA</b><br><span>${DEMO ? "Démo (pas encore connecté)" : "Connecté"}</span></div><b class="${DEMO ? "pill-demo" : "pill-ok"}">${DEMO ? "● Démo" : "● Actif"}</b></div>
        <div class="li"><div><b>Identifiant client</b><br><span>À donner lors d'un achat</span></div><b>${userId}</b></div>
        <button data-go="terms"><div><b>Règles d'utilisation</b><br><span>Ce qui est autorisé et interdit</span></div>›</button>
        <button id="maj"><div><b>Mises à jour</b><br><span>Automatiques à l'ouverture de l'application</span></div>›</button>
        <button id="contact"><div><b>Contacter AMOD REALIX</b><br><span>WhatsApp</span></div>›</button>
        <button id="clear"><div><b>Effacer mes vidéos</b><br><span>Supprime l'historique de ce téléphone</span></div>›</button>
      </div>
      <p class="note" style="text-align:center;margin-top:24px">AMOD REALIX · version ${window.MAJ ? window.MAJ.version : ""} · AMOD GROUP · Conakry, Guinée</p>`;
    $("#maj").onclick = () => { if (window.MAJ && window.Capacitor?.Plugins?.CapacitorUpdater) { toast("Recherche d'une mise à jour…"); window.MAJ.verifier(); } else toast("Application à jour."); };
    $("#contact").onclick = () => window.open(`https://wa.me/${C.WHATSAPP}?text=${encodeURIComponent("Bonjour AMOD REALIX, ")}`, "_blank");
    $("#clear").onclick = () => { sheet(`<h2 style="margin-top:0">Effacer toutes les vidéos ?</h2><button class="btn" id="yes" style="background:var(--bad)">Effacer</button><button class="btn ghost" data-close>Annuler</button>`); $("#yes").onclick = () => { videos = []; saveVideos(); closeSheet(); toast("Historique effacé."); }; };
  };
  VIEWS.terms = (el) => {
    el.innerHTML = `<button class="back" data-go="settings">‹ Réglages</button><h1>Règles d'utilisation</h1>
      <div class="card"><b>Interdit</b><ul class="tips">
        <li>Utiliser le visage ou la voix d'une vraie personne sans son accord.</li>
        <li>Imiter une personnalité, un responsable politique ou religieux.</li>
        <li>Créer de fausses informations, des arnaques ou des contenus trompeurs.</li>
        <li>Contenus violents, haineux, sexuels, ou impliquant des enfants.</li></ul></div>
      <div class="card"><b>Obligatoire</b><ul class="tips">
        <li>Les vidéos d'essai (crédits offerts) portent la mention « AMOD REALIX · IA ». Les vidéos payées sont livrées sans mention.</li>
        <li>Ne présentez jamais une vidéo IA comme un vrai enregistrement pour tromper quelqu'un.</li>
        <li>Vous êtes responsable des vidéos que vous publiez.</li>
        <li>AMOD REALIX peut refuser une demande et suspendre un compte en cas d'abus.</li></ul></div>
      <div class="card"><b>Crédits</b><ul class="tips">
        <li>Les crédits sont retirés seulement quand la vidéo est réussie.</li>
        <li>En cas d'échec technique, aucun crédit n'est perdu.</li></ul></div>`;
  };

  /* ---------- démarrage ---------- */
  $("#creditCount").textContent = total();
  try { window.Capacitor?.Plugins?.StatusBar?.setOverlaysWebView({ overlay: false }); window.Capacitor?.Plugins?.StatusBar?.setBackgroundColor({ color: "#FFFFFF" }); window.Capacitor?.Plugins?.StatusBar?.setStyle({ style: "LIGHT" }); } catch (e) {}
  $("#demoBanner").classList.remove("hidden");
  (async () => {
    if (!C.ENGINE_URL) return;
    try {
      const r = await fetch(C.ENGINE_URL + "/status", { cache: "no-store" });
      const s = await r.json();
      if (s.ready) { DEMO = false; $("#demoBanner").classList.add("hidden"); if (current === "home" || current === "settings") go(current); }
    } catch (e) { /* hors ligne : on reste en démo */ }
  })();
  try { speechSynthesis.getVoices(); speechSynthesis.onvoiceschanged = () => {}; } catch (e) {}
  document.addEventListener("backbutton", () => go("home"));
  try { window.Capacitor?.Plugins?.App?.addListener("backButton", () => { if (!$("#sheet").classList.contains("hidden")) return closeSheet(); if (current !== "home") go("home"); else window.Capacitor.Plugins.App.exitApp(); }); } catch (e) {}
  go("home");
})();
