/* =====================================================================
   AMOD REALIX — mises à jour automatiques (sans réinstaller l'APK)
   Au démarrage, l'application regarde s'il existe une nouvelle version
   (fichier version.json publié sur le site). Si oui, un petit bandeau
   « Mise à jour disponible » s'affiche ; un appui l'installe.
   ===================================================================== */
const VERSION_WEB = '2026.11.26.4';
const NOTES_MAJ = [
  'Moteur IA connecté : passe en vraies vidéos dès que Google est activé',
];
(function(){
  const URL_MAJ = 'https://amodgroup031-cloud.github.io/amod-realix-web/app/version.json';
  const PL = () => (window.Capacitor && window.Capacitor.Plugins) || {};
  const CU = () => PL().CapacitorUpdater;
  // À appeler tout de suite : confirme que cette version démarre bien (sinon retour automatique à l'ancienne).
  if (CU()) CU().notifyAppReady().catch(() => {});

  const lire = k => { try { return localStorage.getItem(k); } catch(e){ return null; } };
  const ecrire = (k, v) => { try { localStorage.setItem(k, v); } catch(e){} };
  const plusRecente = (a, b) => {
    const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0; }
    return false;
  };
  // calculé tout de suite, avant que l'application n'enregistre ses données
  const PREMIERE = !lire('rx-maj-vue') && !lire('rx_videos') && !lire('rx_uid');
  const e = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  // Grand écran (au-dessus de toute l'application)
  function ecran(contenu){
    let el = document.getElementById('majEcran');
    if (!el) { el = document.createElement('div'); el.id = 'majEcran'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); document.body.appendChild(el); }
    el.innerHTML = `<div class="maj-in">
      <img class="maj-logo" src="img/mark.png" alt="">
      ${contenu}</div>`;
    el.hidden = false;
    return el;
  }
  const fermer = () => { const el = document.getElementById('majEcran'); if (el) el.hidden = true; };
  const liste = notes => `<ul class="maj-notes">${(notes || []).map(n => `<li>${e(n)}</li>`).join('')}</ul>`;

  // Après une mise à jour : aucun écran, on note simplement la version.
  function nouveautes(){ ecrire('rx-maj-vue', VERSION_WEB); }

  // Petit bandeau discret en bas de l'écran
  function bandeau(html){
    let el = document.getElementById('majBandeau');
    if (!el) { el = document.createElement('div'); el.id = 'majBandeau'; document.body.appendChild(el); }
    el.innerHTML = html; el.hidden = false; return el;
  }
  const fermerBandeau = () => { const el = document.getElementById('majBandeau'); if (el) el.hidden = true; };

  async function versionNative(){
    try { const i = await PL().App.getInfo(); return Number(i.build) || 0; } catch(err){ return 0; }
  }

  // 2) Vérifier s'il existe une nouvelle version.
  let enCours = false, derniere = 0;
  async function verifier(){
    if (!CU() || enCours) return;
    enCours = true; derniere = Date.now();
    try {
      let info;
      try { const r = await fetch(URL_MAJ + '?t=' + Date.now(), { cache: 'no-store' }); if (!r.ok) return; info = await r.json(); }
      catch(err){ return; }                // hors ligne : on réessaiera plus tard
      const natif = await versionNative();
      if (info.native_min && natif && natif < info.native_min && info.apk) { proposerApk(info); return; }
      if (!info.web || !info.zip || !info.checksum || !plusRecente(info.web, VERSION_WEB)) return;
      const el = bandeau(`<img src="img/mark.png" alt=""><div class="mb-txt"><b>Mise à jour disponible</b></div><button type="button" id="majGo">Mettre à jour</button><button type="button" id="majX" aria-label="Fermer">✕</button>`);
      el.querySelector('#majX').onclick = fermerBandeau;
      el.querySelector('#majGo').onclick = () => installer(info, el);
    } finally { enCours = false; }
  }

  async function installer(info, el){
    el.innerHTML = `<img src="img/mark.png" alt=""><div class="mb-txt"><b id="majPct">Mise à jour… 0 %</b><div class="maj-barre"><i id="majBarre" style="width:3%"></i></div></div>`;
    let ecoute = null;
    try { ecoute = await CU().addListener('download', st => { const p = Math.max(3, Math.min(100, Number(st.percent) || 0)); const b = el.querySelector('#majBarre'); if (b) b.style.width = p + '%'; const t = el.querySelector('#majPct'); if (t) t.textContent = `Mise à jour… ${Math.round(p)} %`; }); } catch(err){}
    try {
      const bundle = await CU().download({ url: info.zip, version: info.web, checksum: info.checksum });
      await CU().set({ id: bundle.id });        // l'application redémarre sur la nouvelle version
    } catch(err){
      if (ecoute) try { ecoute.remove(); } catch(x){}
      el.innerHTML = `<img src="img/mark.png" alt=""><div class="mb-txt"><b>Connexion faible</b><span>Réessayez plus tard</span></div><button type="button" id="majX">OK</button>`;
      el.querySelector('#majX').onclick = fermerBandeau;
    }
  }

  // Rare : nouvelle version de l'application elle-même (nouvelle fonction du téléphone).
  function proposerApk(info){
    const el = ecran(`<h2>Nouvelle version à installer</h2><p class="maj-sous">Cette mise à jour demande d'installer la nouvelle application (${e(info.apk_version || '')}). Vos vidéos et vos crédits restent enregistrés.</p>
      ${liste(info.notes)}
      <button class="btn" type="button" id="majApk">Télécharger la nouvelle version</button>
      <button class="btn ghost" type="button" id="majPlusTard" style="margin-top:8px">Plus tard</button>`);
    el.querySelector('#majApk').onclick = () => {
      const AL = PL().AppLauncher;
      if (AL) AL.openUrl({ url: info.apk }).catch(() => { window.location.href = info.apk; }); else window.open(info.apk, '_blank');
    };
    el.querySelector('#majPlusTard').onclick = fermer;
  }

  window.MAJ = { version: VERSION_WEB, verifier, versionNative };
  const demarrer = () => {
    nouveautes();
    verifier();
    try { PL().App.addListener('resume', () => { if (Date.now() - derniere > 30 * 60e3) verifier(); }); } catch(err){}
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', demarrer); else demarrer();
})();
